Please leave this option enabled.  It forces Octolapse to log all errors in all cases.  It is VERY useful for debugging some problems.
