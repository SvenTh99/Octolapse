How to align the entire block of overlay.  Either centers the text between the left and right side of the timelapse, or forces it to the left or right.
