Apply CbCr effects to to your current Color Effect.

For the Raspberry Pi camera module v2 - CbCr only affects the picture when the Color Effect is set to Aqua, Black and White, Sepia or Set CbCr.  Also, the CbCr must be adjusted AFTER setting the color effect. Due to the ordering issue, it's possible that Octolapse may not apply the settings correctly, giving you an inconsistent effect after reboots or before a new print.  This issue is being investigated, and if at all possible, will be resolved.  For now I recommend that you do NOT use the Color Effects listed above.
