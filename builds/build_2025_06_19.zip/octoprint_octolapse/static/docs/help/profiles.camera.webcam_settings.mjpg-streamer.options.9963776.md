Adjust the brightness of the webcam image.  Lower values are darker, higher values are brighter.
