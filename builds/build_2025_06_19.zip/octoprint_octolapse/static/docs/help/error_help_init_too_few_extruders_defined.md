Your printer profile has fewer extruders defined than your gcode file.  Please increase the number of extruders in your printer profile.
