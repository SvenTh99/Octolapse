This is the minimum height change necessary to trigger a layer change. It can be used to prevent problems with vase mode.

Note:  If this value is higher than your layer height, Octolapse will miss snapshots on some layers.
