This setting is used to tell Octolapse which speed to use when priming after a snapshot has taken place.  Set to 0 always prime at the retraction speed.
