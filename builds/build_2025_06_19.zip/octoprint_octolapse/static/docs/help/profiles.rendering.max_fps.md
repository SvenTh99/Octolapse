When calculating a fixed run length, this will be the highest framerate allowed.  see the FPS type option for details.
