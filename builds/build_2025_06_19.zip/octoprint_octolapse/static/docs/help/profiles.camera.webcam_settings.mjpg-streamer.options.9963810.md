Rotate your image.
