By default Octolapse will cancel printing before any gcodes are sent when startup problems are detected. Disable this option if you would like the print to continue even if obvious problems with Octolapse are detected.

Note: An error message will still be displayed if this option is disabled. Disable Octolapse to prevent this
