This setting is used to tell Octolapse which speed to use when priming/deretracting after a snapshot has taken place.  Set to 0 always deretract at the retraction speed.
