
Here you can enable or disable Octolapse entirely.  Note that if timelapse is currently running, it will still complete.
