Some firmware uses the T1 gcode command for the first extruder.  Other firmware uses T0 as the first extruder.  If your firmware uses T0 to select the first tool, check this box.
