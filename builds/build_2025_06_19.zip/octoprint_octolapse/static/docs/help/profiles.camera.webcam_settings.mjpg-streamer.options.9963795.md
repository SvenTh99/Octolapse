Increase the brightness without increasing the exposure.  You can somewhat compensate for lower light levels, but you may notice that some colors tend to wash out if your gain is too high.
