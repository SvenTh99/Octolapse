Octolapse will wait at least this amount of time before taking a snapshot.  If the print is paused, the timer stops.  The timer also stops while the snapshot is being taken.

Don't set this value too low, especially for a very long print, else you might have way too many snapshots and poor quality.
