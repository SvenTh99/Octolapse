Determines the origin location of your printer.  You can choose from the following types:

1. Front Left - Assume the origin is at the front left of your bed
2. Center - Assume the origin is at the center of the bed
3. Custom - Enter the X Y Z coordinates of your printer's origin
