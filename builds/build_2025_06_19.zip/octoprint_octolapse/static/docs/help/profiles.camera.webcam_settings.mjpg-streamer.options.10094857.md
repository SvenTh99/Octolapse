0 is centered.  Some cameras have digital tilt, and require that your image is zoomed in for tilt to work, since it's just cropping out a section of your image to simulate tilt.

Tilt will move your webcam image up and down.  Some cameras have digital (non-mechanical) tilt, and require that your image is zoomed in for tilt to work, since it's just cropping out a section of your image to simulate tilt.  If this setting has no effect, and your camera has a 'zoom' option, try increasing the zoom and try the tilt setting again.
