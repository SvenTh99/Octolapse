This is called after printing is completed or fails.

The *Test* button will run this script with the **Snapshot Timeout**, but during a live print there is no timeout.  This is to prevent scripts from running for an unusual amount of time when testing.

Parameters:

* Camera Name - The name of the camera profile used to generate the images
