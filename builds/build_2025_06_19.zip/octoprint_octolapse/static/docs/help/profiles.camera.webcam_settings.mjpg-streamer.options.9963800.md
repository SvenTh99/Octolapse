Supposedly this eliminates flicker according to the frequency of your mains power, but I haven't noticed any effect.  Someone let me know if they notice any effect here.
