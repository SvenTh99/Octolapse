When enabled all planned snapshots will be shown on the Octolapse tab when using the smart layer trigger.  Snapshot plan information will not be shown when using any of the real time triggers, like the timer, gcode and classic layer trigger.

Note:  This slider does NOT control the snapshot plan preview popup.  You can enable/disable the snapshot plan preview within the *Main Settings* by clicking the <i class="fa fa-gear"></i> (gear) icon, then by clicking *Edit Main Settings*, and finally adjusting the *Snapshot Plan Preview* settings under the *Print Start Options*.
