If manual ISO sensitivity is enabled, you can control the ISO sensitivity here.
