Adjust the contrast of the webcam image.  Lower values have less contrast, higher values have more.
