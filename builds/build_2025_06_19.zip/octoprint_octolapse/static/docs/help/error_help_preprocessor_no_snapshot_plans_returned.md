No snapshots plans were returned.  This can be caused by incorrect printer profile settings or trigger settings.

#### Printer profile settings to check
1.  Make sure your printer volume is entered correctly.
2.  Disable the **Restrict Snapshot Area** setting.
3.  Make sure the **Minimum Layer Height** setting is higher than your printed object is tall.  The default setting here is 0.05MM.
#### Trigger profile settings to check
1.  Check the **Trigger Height** settings and make sure it's set to 0.
