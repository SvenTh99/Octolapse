Tells Octolapse how much your printer will hop after being retracted.  This is used both to detect z-lifts (important for print quality and snapshot position planning), and to tell Octolapse how much to lift while traveling to take a snapshot.  If z-hop is disabled, Octolapse may snag on previously printed layers.  I recommend you use z-hop when using Octolapse.  

Set to 0 to disable z-hop.
