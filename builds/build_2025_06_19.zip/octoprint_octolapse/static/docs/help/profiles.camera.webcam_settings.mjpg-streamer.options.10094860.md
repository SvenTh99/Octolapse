Controls automatic camera focus.  When enabled, your camera will attempt to focus automatically.

Autofocus sounds like a good idea.  However, when it is enabled your snapshots will take longer, and you will likely get either a blurry or flickery timelapse. A much better option is to manually set your focus if your camera has that option.
