The snapshot will be taken at each relative X position provided in order.  When the end of the list is reached, the path is affected by the 'Loop' and 'Invert Loop' settings.
