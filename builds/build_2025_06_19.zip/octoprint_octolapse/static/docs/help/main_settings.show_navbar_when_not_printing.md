When enabled, the Navbar Control will always be visible.  When disabled, it will only appear when Octolapse is running.
