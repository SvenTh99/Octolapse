When enabled, you can view the current position state during a timelapse.  This is a good place to look if Octolapse is not capturing any snapshots.  Octolapse will not track position if the axes are not homed, or if it encounters imperial units, or for some various other reasons.

Note:  This info panel currently is only available when using real-time triggers.
