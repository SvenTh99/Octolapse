The snapshot will be taken at at a position relative to bed size.  These coordinates depend on the print volume.

In general, 0 will be at the left size of the printer and 100 will be at the right.  Octolapse uses 1 and 99 for the left and right side respectively, to prevent accidental collisions.
