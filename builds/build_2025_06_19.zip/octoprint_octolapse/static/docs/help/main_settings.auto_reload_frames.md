If auto-reload is enabled, Octolapse will keep a number of frames within your browser's cache and will attempt to build up a preview of the final timelapse.  

Each frame for the animation is cached in memory, so the more frames that are stored the more memory will be required.

Set to 1 to disable animations.
