The number of seconds to wait before automatically closing the snapshot plan preview and continuing the print.
