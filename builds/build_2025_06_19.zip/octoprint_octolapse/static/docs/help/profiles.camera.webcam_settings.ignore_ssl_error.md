If you are using a remote webcam you may want to communicate with it over HTTPS.  Normally a valid SSL certificate is required, but many people are using a self-signed certificate.  You may still see ssl warnings in the log file (plugin_octolapse.log) depending on your debug settings.

Warning:  This option could leave you open to certain kinds of attacks.  If you use this option make sure your local network is secure.
