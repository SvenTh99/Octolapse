If your camera requires authentication you can provide it here.  WARNING:  Your username is stored in plain text within the settings.json file.  Additionally if you enable certain diagnostic logging (log settings save, log settings load), your username will appear within the log file!  Finally, if you are using a remote webcam without SSL your username will be sent in PLAIN TEXT over the network!

If you leave the username field blank, no sign-in credentials will be sent.
