Here you can upload a custom watermark image and embed it within your timelapse.  Select 'enabled' here to embed the selected watermark.
