In general the 'Fast' smart trigger will not give you acceptable print quality.  It is usually best to select one of the high quality smart triggers'

However, in some situations the fast trigger may be ideal.  For example, if you are using a wipe tower, using the fast trigger and a stabilization that is closer to the wipe tower than to your printed part can result in excellent print quality. 
