When customize profile is enabled you will be able to view and tweak the profile settings.  When it is disabled, the profile will update automatically from the server, erasing any custom changes.
