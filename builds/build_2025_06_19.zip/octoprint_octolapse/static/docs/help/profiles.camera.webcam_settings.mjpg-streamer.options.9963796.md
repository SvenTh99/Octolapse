Flip (mirror) the image across the horizontal axis.
