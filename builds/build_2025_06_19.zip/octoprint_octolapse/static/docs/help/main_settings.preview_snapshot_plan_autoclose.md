When enabled, the snapshot plan preview will automatically close after a number of seconds.  This is useful if you want to preview the snapshot plan normally, but occasionally want to start your print without access to the Octoprint website.  For example, if you start your prints with the Cura OctoPrint plugin, or from an Octoprint mobile app.

Once this option is enabled, you can configure the number of seconds to wait with the 'Auto-Close Snapshot Plan Preview Seconds' setting.
