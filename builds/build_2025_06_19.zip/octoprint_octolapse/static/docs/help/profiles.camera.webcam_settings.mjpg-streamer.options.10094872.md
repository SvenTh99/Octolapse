Sets the ISO sensitivity to either automatic or manual.  This setting will only have an effect if exposure is automatic.
