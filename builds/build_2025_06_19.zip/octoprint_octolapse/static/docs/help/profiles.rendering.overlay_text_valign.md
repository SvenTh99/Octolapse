How to align the entire block of overlay vertically.  Either centers the text between the top and bottom of the timelapse, or forces it all the way to the top or bottom.
