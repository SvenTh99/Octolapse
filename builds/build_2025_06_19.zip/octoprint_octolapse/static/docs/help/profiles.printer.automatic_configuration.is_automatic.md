When enabled Octolapse will automatically configure and update your printer profile from the server.  This option is highly recommended.
