An attempt was made to preprocess a gcode file, an unexpected error was returned.  This could be due to an octolapse installation problem, specifically compiling the gocde preprocessor.  It could also be an unexpected settings issue, an incompatible version of OctoPrint, a file corruption or permissions issue or a programming error in Octolapse.  It's time to report an issue.

#### Report an Issue
If you are willing to help me debug your problem (which takes time and effort for both of us), please <a href="https://github.com/FormerLurker/Octolapse/wiki/V0.4---Reporting-An-Issue" title="How to report an issue in the Octolapse github repository" target="_blank">see this guide for reporting an issue</a>.
