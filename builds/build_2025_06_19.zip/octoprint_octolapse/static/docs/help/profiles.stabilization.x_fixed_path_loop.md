If Loop is not enabled, the final coordinate will repeat for each subsequent snapshot.  

Take the following X Stabilization Path:
50, 51, 52

If six snapshots are taken, they will be taken at the following coordinates:
50, 51, 52, 52, 52

When Loop is enabled, it will start over at the beginning of the list.  Using the x stabilization path from above, here are the 6 coordinates that would be generated when Loop is enabled
50,51,52,50,51,52
