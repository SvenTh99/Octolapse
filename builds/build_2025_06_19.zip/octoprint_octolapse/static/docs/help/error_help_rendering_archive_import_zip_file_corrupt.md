The zip file you are attempting to import is either in the wrong format, or is corrupted.

### Possible Solutions
1.  Make sure your archive is in zip format.
2.  Extract and re-create your archive.  It is OK to put all of your files in the root of the zip.
3.  Re-upload the zip file.  It is possible that the file was corrupted during upload.
