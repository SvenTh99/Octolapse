Octolapse attempted to start, but was disabled.  This probably means that Octolapse was disabled from another browser while you were starting a print.  It could also be a bug.

#### Report an Issue
If you are willing to help me debug your problem (which takes time and effort for both of us), please <a href="https://github.com/FormerLurker/Octolapse/wiki/V0.4---Reporting-An-Issue" title="How to report an issue in the Octolapse github repository" target="_blank">see this guide for reporting an issue</a>.  When you submit your issue, be sure to include your gcode file, and the exact slicer version you used to create your gcode file.
